import boto3
import os


s3 = boto3.client('s3')
ses = boto3.client('ses', region_name='us-east-1')

def lambda_handler(event, context):
    gorgias_addr = os.environ.get('GORGIAS_FORWARD_ADDR')
    
    ses_notification = event['Records'][0]['ses']
    bucket_name = ses_notification['receipt']['action']['bucketName']
    object_key = ses_notification['receipt']['action']['objectKey']
    
    try:
        email_obj = s3.get_object(Bucket=bucket_name, Key=object_key)
        raw_email_data = email_obj['Body'].read()        

        ses.send_raw_email(
            Source=f"support@sydneycastles.com",
            Destinations=[gorgias_addr],
            RawMessage={
                'Data': raw_email_data
            }
        )
        print(f"Successfully forwarded email {object_key} to {gorgias_addr}")
        
    except Exception as e:
        print(f"Error processing email {object_key}: {str(e)}")
        raise e
